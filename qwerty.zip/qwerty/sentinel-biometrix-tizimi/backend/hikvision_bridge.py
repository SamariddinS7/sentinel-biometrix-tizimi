"""
HikVision Bridge — connects HikVisionManager RTSP camera threads
to Sentinel Biometrix AI pipeline (CameraPipeline.inject_frame).

Architecture:
  CameraThread (RTSP) → frame_ready signal → HikVisionBridge → inject_frame(bytes) → CameraPipeline (AI)

This bridge also stores the latest raw frame per camera for GUI display.
"""

import cv2
import logging
import threading
from typing import Dict, Optional, Callable
from pathlib import Path

logger = logging.getLogger("HikVisionBridge")


class CameraBridge:
    """
    Bridges one HikVisionManager CameraThread to an optional AI pipeline.
    Stores the latest raw frame for GUI consumption.
    """

    def __init__(
        self,
        camera_name: str,
        pipeline=None,          # Optional CameraPipeline — may be None if AI deps missing
        on_frame: Optional[Callable] = None,
    ):
        self.camera_name = camera_name
        self.pipeline = pipeline
        self.on_frame = on_frame   # External callback (e.g. CameraWidget.update_frame)
        self._latest_frame = None
        self._lock = threading.Lock()

    def handle_frame(self, name: str, frame):
        """Called by CameraThread.frame_ready signal for each decoded frame."""
        with self._lock:
            self._latest_frame = frame.copy()

        # Forward to AI pipeline if available
        if self.pipeline is not None:
            try:
                ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
                if ok:
                    self.pipeline.inject_frame(buf.tobytes())
            except Exception as e:
                logger.debug(f"[{name}] AI pipeline inject error: {e}")

        # Forward to external callback (GUI widget etc.)
        if self.on_frame:
            try:
                self.on_frame(name, frame)
            except Exception as e:
                logger.debug(f"[{name}] on_frame callback error: {e}")

    def get_latest_frame(self):
        with self._lock:
            return self._latest_frame


class HikVisionBridge:
    """
    Central manager that:
    1. Creates HikVisionManager CameraThreads for each camera config
    2. Optionally creates Sentinel CameraPipeline instances (if AI deps available)
    3. Routes frames through CameraBridge instances
    """

    def __init__(self, config_path: str = "cameras_config.json"):
        import json, os
        self.config_path = config_path
        self.bridges: Dict[str, CameraBridge] = {}
        self._threads: Dict[str, object] = {}   # CameraThread instances
        self._pipelines: Dict[str, object] = {}  # CameraPipeline instances (optional)
        self._ai_available = self._check_ai_deps()
        self._sentinel_manager = None

        if self._ai_available:
            try:
                from backend.face_recognition.camera_manager import camera_manager as cm
                self._sentinel_manager = cm
                logger.info("Sentinel AI CameraManager loaded successfully.")
            except Exception as e:
                logger.warning(f"Could not load Sentinel CameraManager: {e}")
                self._ai_available = False

    def _check_ai_deps(self) -> bool:
        """Check if Sentinel AI deps are available (InsightFace, etc.)."""
        try:
            import insightface  # noqa
            return True
        except ImportError:
            logger.info("InsightFace not available — AI pipeline disabled (stream-only mode).")
            return False

    def add_camera(self, config: dict, frame_callback=None, status_callback=None) -> bool:
        """
        Add a camera from a config dict:
          {name, ip, username, password, channel, streamUrl (optional)}
        Returns True on success.
        """
        from backend.HikVisionManager.camera_manager import CameraConfig, CameraThread

        name = config["name"]
        if name in self._threads:
            logger.warning(f"Camera '{name}' already registered.")
            return False

        # Build CameraConfig
        cam_cfg = CameraConfig(
            name=name,
            ip=config["ip"],
            username=config.get("username", ""),
            password=config.get("password", ""),
            channel=config.get("channel", 101),
        )

        # Optionally get AI pipeline
        pipeline = None
        if self._ai_available and self._sentinel_manager:
            try:
                pipeline = self._sentinel_manager.get_or_create_pipeline(name, mode="PUSH")
                pipeline.start()
                self._pipelines[name] = pipeline
                logger.info(f"[{name}] Sentinel AI pipeline started.")
            except Exception as e:
                logger.warning(f"[{name}] Could not start AI pipeline: {e}")
                pipeline = None

        # Create bridge
        bridge = CameraBridge(
            camera_name=name,
            pipeline=pipeline,
            on_frame=frame_callback,
        )
        self.bridges[name] = bridge

        # Create and start RTSP thread
        thread = CameraThread(cam_cfg)
        thread.frame_ready.connect(bridge.handle_frame)
        if status_callback:
            thread.connection_status_changed.connect(status_callback)
        thread.start()
        self._threads[name] = thread

        logger.info(f"[{name}] HikVision RTSP thread started → {cam_cfg.rtsp_url}")
        return True

    def remove_camera(self, name: str):
        """Stop and clean up a camera thread + AI pipeline."""
        if name in self._threads:
            thread = self._threads[name]
            thread.stop()
            thread.wait()
            del self._threads[name]
            logger.info(f"[{name}] RTSP thread stopped.")

        if name in self._pipelines and self._sentinel_manager:
            try:
                self._sentinel_manager.remove_camera(name)
            except Exception as e:
                logger.debug(f"[{name}] AI pipeline removal error: {e}")
            del self._pipelines[name]

        if name in self.bridges:
            del self.bridges[name]

    def get_frame(self, name: str):
        """Return the latest raw frame for a given camera name."""
        if name in self.bridges:
            return self.bridges[name].get_latest_frame()
        return None

    def get_all_names(self):
        return list(self._threads.keys())

    def shutdown(self):
        """Stop all cameras gracefully."""
        for name in list(self._threads.keys()):
            self.remove_camera(name)
        if self._ai_available and self._sentinel_manager:
            try:
                self._sentinel_manager.shutdown()
            except Exception:
                pass
        logger.info("HikVisionBridge shutdown complete.")
