"""Camera connection management for HikVisionManager."""

import cv2
from typing import Optional, Dict, Any
from PySide6.QtCore import QObject, Signal, QThread, Slot
from dataclasses import dataclass


@dataclass
class CameraConfig:
    """Camera configuration."""
    name: str
    ip: str
    username: str
    password: str
    channel: int = 101
    
    @property
    def rtsp_url(self) -> str:
        ip_str = str(self.ip).strip()
        if (ip_str.startswith(("rtsp://", "http://", "https://")) or 
                ip_str.endswith(('.mp4', '.avi', '.mkv', '.mov')) or 
                ip_str.isdigit()):
            return ip_str
        return f"rtsp://{self.username}:{self.password}@{self.ip}:554/Streaming/Channels/{self.channel}"


class CameraManager(QObject):
    """Manages camera connections and frame retrieval in separate threads."""
    
    frame_ready = Signal(str, object)
    connection_status_changed = Signal(str, bool)
    error_occurred = Signal(str, str)
    
    _cameras: Dict[str, 'CameraThread'] = {}
    _config: Dict[str, CameraConfig] = {}
    
    def add_camera(self, config: CameraConfig) -> bool:
        """Add and start a camera."""
        if config.name in self._cameras:
            return False
            
        self._config[config.name] = config
        thread = CameraThread(config)
        thread.frame_ready.connect(self.frame_ready)
        thread.connection_status_changed.connect(self.connection_status_changed)
        thread.error_occurred.connect(self.error_occurred)
        thread.start()
        
        self._cameras[config.name] = thread
        return True
        
    def remove_camera(self, name: str):
        """Stop and remove a camera."""
        if name in self._cameras:
            thread = self._cameras[name]
            thread.stop()
            thread.wait()
            del self._cameras[name]
            del self._config[name]
            
    def get_frame(self, name: str) -> Optional[Any]:
        """Get latest frame from camera."""
        if name in self._cameras:
            return self._cameras[name].get_latest_frame()
        return None
        
    def get_all_cameras(self) -> list:
        return list(self._cameras.keys())
        

class CameraThread(QThread):
    """Thread for individual camera capture."""
    
    frame_ready = Signal(str, object)
    connection_status_changed = Signal(str, bool)
    error_occurred = Signal(str, str)
    
    def __init__(self, config: CameraConfig):
        super().__init__()
        self.config = config
        self._running = False
        self._latest_frame = None
        self._reconnect_delay = 3
        
    def run(self):
        """Main capture loop."""
        self._running = True
        
        while self._running:
            url = self.config.rtsp_url
            if url.isdigit():
                cap = cv2.VideoCapture(int(url))
            else:
                cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
            
            if not cap.isOpened():
                self.connection_status_changed.emit(self.config.name, False)
                self.error_occurred.emit(self.config.name, "Camera not available, retrying...")
                self.msleep(self._reconnect_delay * 1000)
                continue
                
            self.connection_status_changed.emit(self.config.name, True)
            
            while self._running and cap.isOpened():
                ret, frame = cap.read()
                
                if not ret:
                    self.connection_status_changed.emit(self.config.name, False)
                    break
                    
                self._latest_frame = frame.copy()
                self.frame_ready.emit(self.config.name, frame)
                
            cap.release()
            self.connection_status_changed.emit(self.config.name, False)
            self.msleep(self._reconnect_delay * 1000)
            
    def stop(self):
        """Stop the thread."""
        self._running = False
        
    def get_latest_frame(self):
        """Get the most recent frame."""
        return self._latest_frame